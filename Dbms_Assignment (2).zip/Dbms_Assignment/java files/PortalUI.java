import java.awt.*;
import javax.swing.*;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
public class PortalUI extends JFrame{
private static final long serialVersionUID = 1L;
private JMenuBar mnu;
private JMenu mnuAccount_holder;
private JMenu mnuBankdetails;
private JMenu mnuPayment;

private JMenuItem insert1, update1, delete1, view1;
private JMenuItem insert2, update2, delete2, view2;
private JMenuItem insert3, update3, delete3, view3;
private JLabel labelName;
private static JPanel p0, p1;
public void initialize() {
mnu = new JMenuBar();
mnuAccount_holder = new JMenu("Account Holder");
mnuBankdetails = new JMenu("Bank details");
mnuPayment = new JMenu("Payment");
Color lightblue= new Color(51, 204, 255);
labelName=new JLabel("IT Returns Processing Database");
labelName.setFont(new Font("Serif", Font.PLAIN, 40));
labelName.setForeground(Color.BLACK);
p1=new JPanel();
p0=new JPanel();
insert1 = new JMenuItem("Insert");
update1 = new JMenuItem("Update");
delete1 = new JMenuItem("Delete");
view1 = new JMenuItem("View");
insert2 = new JMenuItem("Insert");
update2 = new JMenuItem("Update");
delete2 = new JMenuItem("Delete");
view2 = new JMenuItem("View");
insert3 = new JMenuItem("Insert");
update3 = new JMenuItem("Update");
delete3 = new JMenuItem("Delete");
view3 = new JMenuItem("View");
}
void addComponentsToFrame() {
mnuAccount_holder.add(insert1);
mnuAccount_holder.add(delete1);
mnuAccount_holder.add(update1);
mnuAccount_holder.add(view1);
mnuBankdetails.add(insert2);
mnuBankdetails.add(delete2);
mnuBankdetails.add(update2);
mnuBankdetails.add(view2);
mnuPayment.add(insert3);
mnuPayment.add(delete3);
mnuPayment.add(update3);
mnuPayment.add(view3);
mnu.add(mnuAccount_holder);
mnu.add(mnuBankdetails);
mnu.add(mnuPayment);
setJMenuBar(mnu);
p1.add(labelName);
p1.setAlignmentY(CENTER_ALIGNMENT);
p1.setBounds(500, 500, 800, 100);
p0.add(p1);
p0.setBackground(Color.WHITE);
add(p0);
}
void closeWindow(){
try {
int a = JOptionPane.showConfirmDialog(this,"Are you sure want to Quit ?");
if(a == JOptionPane.YES_OPTION){
System.exit(0);
}
else if (a == JOptionPane.NO_OPTION) {
setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
}
else if (a == JOptionPane.CANCEL_OPTION) {
setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
}
}
catch(Exception e) {
System.out.println(e);
}
}
void register() {
Account_holder ah=new Account_holder(p0, PortalUI.this, insert1, update1, view1, delete1);
ah.buildGUI();
Bankdetails bd = new Bankdetails(p0, PortalUI.this, insert2, update2, view2, delete2);
bd.buildGUI();
Payment pt= new Payment(p0, PortalUI.this, insert3, update3, view3, delete3);
pt.buildGUI();

addWindowListener(new WindowAdapter(){
public void windowClosing(WindowEvent we)
{
closeWindow();
}
});
}
public PortalUI() {
initialize();
addComponentsToFrame();
register();
pack();
setTitle("IT Returns Processing Database");
setSize(800, 800);
setVisible(true);
}
}
