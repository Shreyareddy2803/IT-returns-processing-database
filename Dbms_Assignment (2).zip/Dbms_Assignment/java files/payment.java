import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;
public class Payment{
private JPanel pn, pn1, pn2, pn3;
private JFrame jf;
private JButton JB_insert, JB_modify, JB_view, JB_delete;
private JLabel JL_payment_id, JL_tax, JL_due_date, JL_fine,JL_account_number;
private JTextField JTF_payment_id, JTF_tax, JTF_due_date, JTF_fine, JTF_account_number;
private JMenuItem insert2, update2, view2, delete2;
private List Accountholders_List;
private Choice account_number;
public Payment(JPanel pn, JFrame jf, JMenuItem insert2, JMenuItem update2, JMenuItem view2,
JMenuItem delete2){
try {
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e) {
System.err.println("Unable to find and load driver");
System.exit(1);
}
this.jf = jf;
this.insert2 = insert2;
this.update2 = update2;
this.view2 = view2;
this.delete2 = delete2;
JL_payment_id = new JLabel("Payment id :");
JTF_payment_id = new JTextField(10);
JL_tax= new JLabel("Tax :");
JTF_tax = new JTextField(10);
JL_due_date = new JLabel("Due Date:");
JTF_due_date = new JTextField(10);
JL_fine = new JLabel("Fine :");
JTF_fine = new JTextField(10);
JL_account_number = new JLabel("Account number :");
JTF_account_number = new JTextField(10);
this.pn = pn;
}
private void displaySQLErrors(SQLException e) {
JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState: " +
e.getSQLState() + "\n"+"VendorError: " + e.getErrorCode() + "\n");
}
public void load_details(){
try{
account_number = new Choice();
account_number.removeAll();
Connection con1 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
Statement st1 = con1.createStatement();
ResultSet rs1 = st1.executeQuery("select * from Payment");
while(rs1.next()) {
account_number.add(rs1.getString("payment_id"));
}
}
catch(SQLException e) {
displaySQLErrors(e);
}
}
public void loaddetails(){
try{
Accountholders_List = new List();
Accountholders_List.removeAll();
Connection con2 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
Statement st2 = con2.createStatement();
ResultSet rs2 = st2.executeQuery("select * from Payment");
while(rs2.next()) {
Accountholders_List.add(rs2.getString("payment_id"));
}
}
catch(SQLException e) {
displaySQLErrors(e);
}
}
public void buildGUI(){
insert2.addActionListener(new ActionListener(){
@Override
public void actionPerformed(ActionEvent aevt){
JB_insert = new JButton("Submit");
JTF_payment_id.setText(null);
JTF_tax.setText(null);
JTF_due_date.setText(null);
JTF_fine.setText(null);
JTF_account_number.setText(null);
loaddetails();
pn.removeAll();
jf.invalidate();
jf.validate();
jf.repaint();
pn1 = new JPanel();
pn1.setLayout(new GridLayout(10,10));
pn1.add(JL_payment_id);
pn1.add(JTF_payment_id);
pn1.add(JL_tax);
pn1.add(JTF_tax);
pn1.add(JL_due_date);
pn1.add(JTF_due_date);
pn1.add(JL_fine);
pn1.add(JTF_fine);
pn1.add(JL_account_number);
pn1.add(JTF_account_number);
pn3 = new JPanel(new FlowLayout());
pn3.add(JB_insert);
pn1.setBounds(115, 80, 300, 250);
pn3.setBounds(200, 350, 75, 35);
pn2 = new JPanel(new FlowLayout());
Accountholders_List = new List(10);
loaddetails();
pn2.add(Accountholders_List);
pn2.setBounds(200, 350, 300, 180);
pn.add(pn1);
pn.add(pn3);
pn.add(pn2);
pn.setLayout(new BorderLayout());
jf.add(pn);
jf.setSize(800, 800);
jf.validate();
JB_insert.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
try{
Connection con = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041","vasavi");
String query = "INSERT INTO Payment (payment_id,tax, due_date, fine, account_number) values(?, ?, ?, ?)";
PreparedStatement stp1 = con.prepareStatement(query);
stp1.setString(1, JTF_payment_id.getText());
stp1.setString(2, JTF_tax.getText());
stp1.setString(3, JTF_due_date.getText());
stp1.setString(4, JTF_fine.getText());
stp1.setString(4, JTF_account_number.getText());
int i = stp1.executeUpdate();
con.close();
if(i > 0){
JOptionPane.showMessageDialog(pn,"\nInserted successfully");
}
loaddetails();
}
catch(SQLException e) {
displaySQLErrors(e);
}
}
});
}
});
update2.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
JB_modify=new JButton("Modify");
JTF_payment_id.setText(null);
JTF_tax.setText(null);
JTF_due_date.setText(null);
JTF_fine.setText(null);
JTF_account_number.setText(null);
pn.removeAll();
jf.invalidate();
jf.validate();
jf.repaint();
pn1=new JPanel();
pn1.setLayout(new GridLayout(10, 10));
pn1.add(JL_payment_id);
pn1.add(JTF_payment_id);
pn1.add(JL_tax);
pn1.add(JTF_tax);
pn1.add(JL_due_date);
pn1.add(JTF_due_date);
pn1.add(JL_fine);
pn1.add(JTF_fine);
pn1.add(JL_account_number);
pn1.add(JTF_account_number);
pn3 = new JPanel(new FlowLayout());
pn3.add(JB_modify);
pn1.setBounds(115, 80, 300, 250);
pn3.setBounds(200, 350, 75, 35);
pn2 =new JPanel(new FlowLayout());
Accountholders_List = new List(10);
loaddetails();
pn2.add(Accountholders_List);
pn2.setBounds(200, 350, 300, 180);
pn.add(pn1);
pn.add(pn3);
pn.add(pn2);
pn.setLayout(new BorderLayout());
jf.add(pn);
jf.setSize(800, 800);
jf.validate();
Accountholders_List.addItemListener(new ItemListener() {
public void itemStateChanged(ItemEvent ievt){
try {
Connection con3 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms", "it20737041", "vasavi");
Statement st3 = con3.createStatement();
ResultSet rs3 = st3.executeQuery("select * from Payment");
while (rs3.next()) {
if
(rs3.getString("payment_id").equals(Accountholders_List.getSelectedItem()))
break;
}
if (!rs3.isAfterLast()) {
JTF_payment_id.setText(rs3.getString("payment_id"));
JTF_tax.setText(rs3.getString("tax"));
JTF_due_date.setText(rs3.getString("due_date"));
JTF_fine.setText(rs3.getString("fine"));
JTF_account_number.setText(rs3.getString("account_number"));
}
}
catch (SQLException selectException) {
displaySQLErrors(selectException);
}
}
});
JB_modify.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
try{
int a = JOptionPane.showConfirmDialog(pn, "Are you sure want to update:");
if(a == JOptionPane.YES_OPTION){
String query = "update Payment set tax = ?, fine = ?, due_date = ?, account_number = ? where paymentid = ?";
Connection con4 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms", "it20737041", "vasavi");
PreparedStatement stp2 = con4.prepareStatement(query);
stp2.setString(1, JTF_tax.getText());
stp2.setString(2, JTF_fine.getText());
stp2.setString(3, JTF_due_date.getText());
stp2.setString(4, JTF_account_number.getText());
stp2.setString(5, JTF_payment_id.getText());
int i = stp2.executeUpdate();
if(i>0){
JOptionPane.showMessageDialog(pn,"\nUpdated rows succesfully");
}
loaddetails();
}
}
catch(SQLException e){
displaySQLErrors(e);
}
}
});
}
});
delete2.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
JB_delete = new JButton("Delete");
JTF_payment_id.setText(null);
JTF_tax.setText(null);
JTF_due_date.setText(null);
JTF_fine.setText(null);
JTF_account_number.setText(null);
pn.removeAll();
jf.invalidate();
jf.validate();
jf.repaint();
pn1 = new JPanel();
pn1.setLayout(new GridLayout(10, 10));
pn1.add(JL_payment_id);
pn1.add(JTF_payment_id);
pn1.add(JL_tax);
pn1.add(JTF_tax);
pn1.add(JL_due_date);
pn1.add(JTF_due_date);
pn1.add(JL_fine);
pn1.add(JTF_fine);
pn1.add(JL_account_number);
pn1.add(JTF_account_number);
pn3 = new JPanel(new FlowLayout());
pn3.add(JB_delete);
pn1.setBounds(115, 80, 300, 250);
pn3.setBounds(200, 350, 75, 35);
pn2 = new JPanel(new FlowLayout());
Accountholders_List = new List(10);
loaddetails();
pn2.add(Accountholders_List);
pn2.setBounds(200, 350, 300, 200);
pn.add(pn1);
pn.add(pn3);
pn.add(pn2);
pn.setLayout(new BorderLayout());
jf.add(pn);
jf.setSize(800, 800);
jf.validate();
Accountholders_List.addItemListener(new ItemListener() {
public void itemStateChanged(ItemEvent ievt){
try {
Connection con5 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms", "it20737041", "vasavi");
Statement st4 = con5.createStatement();
ResultSet rs4 = st4.executeQuery("select * from Payment");
while (rs4.next()) {
if
(rs4.getString("account_number").equals(Accountholders_List.getSelectedItem()))
break;
}
if (!rs4.isAfterLast()) {
JTF_payment_id.setText(rs4.getString("payment_id"));
JTF_tax.setText(rs4.getString("tax"));
JTF_due_date.setText(rs4.getString("due_date"));
JTF_fine.setText(rs4.getString("fine"));
JTF_account_number.setText(rs4.getString("account_number"));
}
}
catch (SQLException selectException) {
displaySQLErrors(selectException);
}
}
});
JB_delete.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
try {
int a = JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
if(a == JOptionPane.YES_OPTION){
String query = "DELETE FROM Payment WHERE payment_id = ?";
Connection con6 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms", "it20737041", "vasavi");
PreparedStatement stp3 = con6.prepareStatement(query);
stp3.setString(1, JTF_payment_id.getText());
int i = stp3.executeUpdate();
if(i > 0){
JOptionPane.showMessageDialog(pn,"\nDeleted rows succesfully");
}
loaddetails();
}
}
catch(SQLException e){
displaySQLErrors(e);
}
}
});
}
});
view2.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
pn.removeAll();
jf.invalidate();
jf.validate();
jf.repaint();
JLabel view = new JLabel("payment details View");
view.setForeground(Color.BLACK);
JB_view = new JButton("View");
Font myFont = new Font("Serif",Font.BOLD,25);
view.setFont((myFont));
pn1 = new JPanel();
pn2 = new JPanel();
pn1.add(view);
pn2.add(JB_view);
pn.add(pn1);
pn.add(pn2);
pn.setBounds(500, 800, 300, 300);
pn.setLayout(new FlowLayout());
jf.add(pn);
jf.setSize(800, 800);
jf.validate();
JB_view.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
JFrame jfr = new JFrame("Payment details");
JTable jt;
DefaultTableModel model = new DefaultTableModel();
jt = new JTable(model);
model.addColumn("payment_id");
model.addColumn("tax");
model.addColumn("due_date");
model.addColumn("fine");
model.addColumn("account_number");
try {
Connection con7 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms", "it20737041", "vasavi");
Statement st4 = con7.createStatement();
ResultSet rs5 = st4.executeQuery("select * from payment");
while(rs5.next()){
model.addRow(new Object[]{rs5.getString("payment_id"), rs5.getString("tax"), rs5.getString("due_date"), rs5.getString("fine"), rs5.getString("account_number")});
}
}
catch(SQLException e){
displaySQLErrors(e);
}
jt.setEnabled(false);
jt.setBounds(30, 40, 300, 300);
JScrollPane jsp = new JScrollPane(jt);
jfr.add(jsp);
jfr.setSize(800, 400);
jfr.setVisible(true);
}
});
}
});
}
}