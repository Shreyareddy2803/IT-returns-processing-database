import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Properties;
public class Bankdetails{
private JPanel pn, pn1, pn2, pn3;
private JFrame jf;
private JButton JB_insert, JB_modify, JB_view, JB_delete;
private JLabel JL_utr, JL_account_number, JL_annual_income, JL_address, JL_tax;
private JTextField JTF_utr, JTF_account_number, JTF_annual_income, JTF_address, JTF_tax;
private JMenuItem insert2, update2, view2, delete2;
private List Accountholders_List;
private Choice account_number;
public Bankdetails(JPanel pn, JFrame jf, JMenuItem insert2, JMenuItem update2, JMenuItem view2, JMenuItem
delete2){
try {
Class.forName("oracle.jdbc.driver.OracleDriver");
}
catch (Exception e) {
System.err.println("Unable to find and load driver");
System.exit(1);
}
this.jf = jf;
this.insert2 = insert2;
this.update2 = update2;
this.view2 = view2;
this.delete2 = delete2;
JL_utr = new JLabel("Utr : ");
JTF_utr = new JTextField(10);
JL_account_number = new JLabel("account number : ");
JTF_account_number = new JTextField(10);
JL_annual_income = new JLabel("annual income : ");
JTF_annual_income = new JTextField(10);
JL_address = new JLabel("Address : ");
JTF_address = new JTextField(10);
JL_tax = new JLabel("Tax : ");
JTF_tax = new JTextField(10);
this.pn=pn;
}
private void displaySQLErrors(SQLException e) {
JOptionPane.showMessageDialog(pn1,"\nSQLException: " + e.getMessage() + "\n"+"SQLState: " +
e.getSQLState() + "\n"+"VendorError: " + e.getErrorCode() + "\n");
}
public void load_details(){
try{
account_number = new Choice();
account_number.removeAll();
Connection con1 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
Statement st1 = con1.createStatement();
ResultSet rs1 = st1.executeQuery("select * from bankdetails");
while(rs1.next()) {
account_number.add(rs1.getString("utr"));
}
}
catch(SQLException e) {
displaySQLErrors(e);
}
}
public void loaddetails(){
try{
Accountholders_List = new List();
Accountholders_List.removeAll();
Connection con2 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
Statement st2 = con2.createStatement();
ResultSet rs2 = st2.executeQuery("select * from bankdetails");
while(rs2.next()) {
Accountholders_List.add(rs2.getString("utr"));
}
}
catch(SQLException e) {
displaySQLErrors(e);
}
}
public void buildGUI(){
insert2.addActionListener(new ActionListener(){
@Override
public void actionPerformed(ActionEvent aevt){
JB_insert = new JButton("Submit");
JTF_utr.setText(null);
JTF_account_number.setText(null);
JTF_annual_income.setText(null);
JTF_address.setText(null);
JTF_tax.setText(null);
loaddetails();
pn.removeAll();
jf.invalidate();
jf.validate();
jf.repaint();
pn1 = new JPanel();
pn1.setLayout(new GridLayout(10,10));
pn1.add(JL_utr);
pn1.add(JTF_utr);
pn1.add(JL_account_number);
pn1.add(JTF_account_number);
pn1.add(JL_annual_income);
pn1.add(JTF_annual_income);
pn1.add(JL_address);
pn1.add(JTF_address);
pn1.add(JL_tax);
pn1.add(JTF_tax);
pn3 = new JPanel(new FlowLayout());
pn3.add(JB_insert);
pn1.setBounds(115, 80, 300, 250);
pn3.setBounds(200, 350, 75, 35);
pn2 = new JPanel(new FlowLayout());
Accountholders_List = new List(10);
loaddetails();
pn2.add(Accountholders_List);
pn2.setBounds(200, 350, 300, 180);
pn.add(pn1);
pn.add(pn3);
pn.add(pn2);
pn.setLayout(new BorderLayout());
jf.add(pn);
jf.setSize(800, 800);
jf.validate();
JB_insert.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
try{
Connection con = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
String query = "INSERT INTO bankdetails (utr, account_number, annual_income, address, tax) values(?, ?, ?, ?, ?)";
PreparedStatement stp = con.prepareStatement(query);
stp.setString(1, JTF_utr.getText());
stp.setString(2, JTF_account_number.getText());
stp.setString(3, JTF_annual_income.getText());
stp.setString(4, JTF_address.getText());
stp.setString(5, JTF_tax.getText());
int i = stp.executeUpdate();
con.close();
if(i > 0){
JOptionPane.showMessageDialog(pn,"\nInserted successfully");
}
}
catch(SQLException e) {
displaySQLErrors(e);
}
}
});
}
});
update2.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
JB_modify = new JButton("Modify");
JTF_utr.setText(null);
JTF_account_number.setText(null);
JTF_annual_income.setText(null);
JTF_address.setText(null);
JTF_tax.setText(null);
pn.removeAll();
jf.invalidate();
jf.validate();
jf.repaint();
pn1 = new JPanel();
pn1.setLayout(new GridLayout(10, 10));
pn1.add(JL_utr);
pn1.add(JTF_utr);
pn1.add(JL_account_number);
pn1.add(JTF_account_number);
pn1.add(JL_annual_income);
pn1.add(JTF_annual_income);
pn1.add(JL_address);
pn1.add(JTF_address);
pn1.add(JL_tax);
pn1.add(JTF_tax);
pn3 = new JPanel(new FlowLayout());
pn3.add(JB_modify);
pn1.setBounds(115, 80, 300, 250);
pn3.setBounds(200, 350, 75, 35);
pn2 =new JPanel(new FlowLayout());
Accountholders_List = new List(10);
loaddetails();
pn2.add(Accountholders_List);
pn2.setBounds(200, 350, 300, 180);
pn.add(pn1);
pn.add(pn3);
pn.add(pn2);
pn.setLayout(new BorderLayout());
jf.add(pn);
jf.setSize(800, 800);
jf.validate();
Accountholders_List.addItemListener(new ItemListener() {
public void itemStateChanged(ItemEvent ievt){
try {
Connection con3 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
Statement st3 = con3.createStatement();
ResultSet rs3 = st3.executeQuery("select * from bankdetails");
while (rs3.next()) {
if
(rs3.getString("utr").equals(Accountholders_List.getSelectedItem()))
break;
}
if (!rs3.isAfterLast()) {
JTF_utr.setText(rs3.getString("utr"));
JTF_account_number.setText(rs3.getString("account_number"));
JTF_annual_income.setText(rs3.getString("annual_income"));
JTF_tax.setText(rs3.getString("address"));
JTF_address.setText(rs3.getString("tax"));
}
}
catch (SQLException selectException) {
displaySQLErrors(selectException);
}
}
});
JB_modify.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
try{
int a = JOptionPane.showConfirmDialog(pn, "Are you sure want to update:");
if(a == JOptionPane.YES_OPTION){
String query = "update bankdetails set accountnumber = ?, tax = ?, annualincome = ?, address = ? where utr = ?";
Connection con4 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
PreparedStatement stp2 = con4.prepareStatement(query);
stp2.setString(1, JTF_account_number.getText());
stp2.setString(3, JTF_annual_income.getText());
stp2.setString(4, JTF_address.getText());
stp2.setString(2, JTF_tax.getText());
stp2.setString(5, JTF_utr.getText());
int i = stp2.executeUpdate();
if(i>0){
JOptionPane.showMessageDialog(pn,"\nUpdated rows succesfully");
}
loaddetails();
}
}
catch(SQLException e){
displaySQLErrors(e);
}
}
});
}
});
delete2.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
JB_delete = new JButton("Delete");
JTF_utr.setText(null);
JTF_account_number.setText(null);
JTF_annual_income.setText(null);
JTF_address.setText(null);
JTF_tax.setText(null);
pn.removeAll();
jf.invalidate();
jf.validate();
jf.repaint();
pn1 = new JPanel();
pn1.setLayout(new GridLayout(10, 10));
pn1.add(JL_utr);
pn1.add(JTF_utr);
pn1.add(JL_account_number);
pn1.add(JTF_account_number);
pn1.add(JL_annual_income);
pn1.add(JTF_annual_income);
pn1.add(JL_address);
pn1.add(JTF_address);
pn1.add(JL_tax);
pn1.add(JTF_tax);
pn3 = new JPanel(new FlowLayout());
pn3.add(JB_delete);
pn1.setBounds(115, 80, 300, 250);
pn3.setBounds(200, 350, 75, 35);
pn2 = new JPanel(new FlowLayout());
Accountholders_List = new List(10);
loaddetails();
pn2.add(Accountholders_List);
pn2.setBounds(200, 350, 300, 200);
pn.add(pn1);
pn.add(pn3);
pn.add(pn2);
pn.setLayout(new BorderLayout());
jf.add(pn);
jf.setSize(800, 800);
jf.validate();
Accountholders_List.addItemListener(new ItemListener() {
public void itemStateChanged(ItemEvent ievt){
try {
Connection con5 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
Statement st4 = con5.createStatement();
ResultSet rs4 = st4.executeQuery("select * from bankdetails");
while (rs4.next()) {
if
(rs4.getString("utr").equals(Accountholders_List.getSelectedItem()))
break;
}
if (!rs4.isAfterLast()) {
JTF_utr.setText(rs4.getString("utr"));
JTF_account_number.setText(rs4.getString("account_number"));
JTF_annual_income.setText(rs4.getString("annual_income"));
JTF_tax.setText(rs4.getString("address"));
JTF_address.setText(rs4.getString("tax"));
}
}
catch (SQLException selectException) {
displaySQLErrors(selectException);
}
}
});
JB_delete.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
try {
int a = JOptionPane.showConfirmDialog(pn,"Are you sure want to Delete:");
if(a == JOptionPane.YES_OPTION){
String query = "DELETE FROM bankdetails WHERE utr = ?";
Connection con6 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041", "vasavi");
PreparedStatement stp3 = con6.prepareStatement(query);
stp3.setString(1, JTF_utr.getText());
int i = stp3.executeUpdate();
if(i>0){
JOptionPane.showMessageDialog(pn,"\nDeleted rows succesfully");
}
loaddetails();
}
}
catch(SQLException e){
displaySQLErrors(e);
}
}
});
}
});
view2.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
pn.removeAll();
jf.invalidate();
jf.validate();
jf.repaint();
JLabel view = new JLabel("bank details View");
view.setForeground(Color.BLACK);
JB_view = new JButton("View");
Font myFont = new Font("Serif",Font.BOLD,25);
view.setFont((myFont));
pn1 = new JPanel();
pn2 = new JPanel();
pn1.add(view);
pn2.add(JB_view);
pn.add(pn1);
pn.add(pn2);
pn.setBounds(500, 800, 300, 300);
pn.setLayout(new FlowLayout());
jf.add(pn);
jf.setSize(800, 800);
jf.validate();
JB_view.addActionListener(new ActionListener() {
@Override
public void actionPerformed(ActionEvent aevt){
JFrame jfr = new JFrame("bank details");
JTable jt;
DefaultTableModel model = new DefaultTableModel();
jt = new JTable(model);
model.addColumn("utr");
model.addColumn("account_number");
model.addColumn("annual_income");
model.addColumn("address");
model.addColumn("tax");
try {
Connection con7 = DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms", "it20737041", "vasavi");
Statement st4 = con7.createStatement();
ResultSet rs5 = st4.executeQuery("select * from bankdetails");
while(rs5.next()){
model.addRow(new Object[]{rs5.getString("utr"), rs5.getString("account_number"), rs5.getString("annual_income"), rs5.getString("address"), rs5.getString("tax")});
}
}
catch(SQLException e){
displaySQLErrors(e);
}
jt.setEnabled(false);
jt.setBounds(30, 40, 300, 300);
JScrollPane jsp = new JScrollPane(jt);
jfr.add(jsp);
jfr.setSize(800, 400);
jfr.setVisible(true);
}
});
}
});
}
}