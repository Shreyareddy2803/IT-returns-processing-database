import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Update_payment extends JFrame implements ActionListener,ItemListener{
JLabel l1,l2,l3,l4,emp;
JTextField t1,t2,t3,t4;
JButton b1,b2;
Choice c1,c2;
    
Update_payment(){
        
super("Update payment");
        
setLayout(null);
getContentPane().setBackground(Color.WHITE);
        
c2 = new Choice();
c2.setForeground(Color.WHITE);
c2.setBackground(Color.BLACK);
c2.setBounds(160,40,200,20);
       
try{
conn c = new conn();
ResultSet rs = c.s.executeQuery("select * from payment");
      
while(rs.next()){
c2.add(rs.getString("pid"));    
}
}catch(Exception e){ }
       
emp = new JLabel("Select pid");
emp.setForeground(Color.WHITE);
emp.setBackground(Color.BLACK);
emp.setBounds(40,40,100,20);
add(emp);
add(c2);
        
l1 = new JLabel("Payment_id : ");
l1.setForeground(Color.WHITE);
l1.setBackground(Color.BLACK);

t1 = new JTextField(15);
t1.setForeground(Color.WHITE);
t1.setBackground(Color.BLACK);
        
l1.setBounds(40,80,100,20);
t1.setBounds(160,80,200,20);
add(l1);
add(t1);
       
/*c1 = new Choice();
c1.setForeground(Color.WHITE);
c1.setBackground(Color.BLACK);

c1.add("Male");
c1.add("Female");
       
l2 = new JLabel("Gender : ");
l2.setForeground(Color.WHITE);
l2.setBackground(Color.BLACK);

l2.setBounds(40,120,100,20);
c1.setBounds(160,120,200,20);
add(l2);
add(c1);*/
        
l2 = new JLabel("tax : ");
l2.setForeground(Color.WHITE);
l2.setBackground(Color.BLACK);

t2 = new JTextField(15);
t2.setForeground(Color.WHITE);
t2.setBackground(Color.BLACK);

l2.setBounds(40,160,100,20);
t2.setBounds(160,160,200,20);
add(l2);
add(t2);
        
l3 = new JLabel("due_date : ");
l3.setForeground(Color.WHITE);
l3.setBackground(Color.BLACK);
t3 = new JTextField(15);
t3.setForeground(Color.WHITE);
t3.setBackground(Color.BLACK);

l3.setBounds(40,200,100,20);
t3.setBounds(160,200,200,20);
add(l3);
add(t3); 
        
l4 = new JLabel("fine : ");
l4.setForeground(Color.WHITE);
l4.setBackground(Color.BLACK);

t4 = new JTextField(15);
t4.setForeground(Color.WHITE);
t4.setBackground(Color.BLACK);

l4.setBounds(40,240,100,20);
t4.setBounds(160,240,200,20);
add(l4);
add(t4);
        
/*l6 = new JLabel("utr : ");
l6.setForeground(Color.WHITE);
l6.setBackground(Color.BLACK);

t6 = new JTextField(15);
t6.setForeground(Color.WHITE);
t6.setBackground(Color.BLACK);

l6.setBounds(40,280,100,20);
t6.setBounds(160,280,200,20);
add(l6);
add(t6);
        
l7 = new JLabel("account_number : ");
l7.setForeground(Color.WHITE);
l7.setBackground(Color.BLACK);

t7= new JTextField(15);
t7.setForeground(Color.WHITE);
t7.setBackground(Color.BLACK);

l7.setBounds(40,320,100,20);
t7.setBounds(160,320,200,20);
add(l7);
add(t7);*/
        
b1 =new JButton("Update");
b2 = new JButton("Delete");
        
b1.setBounds(40,400,150,30);
b2.setBounds(200,400,150,30);
add(b1);
add(b2);
        
b1.setBackground(Color.BLACK);
b1.setForeground(Color.WHITE);
        
b2.setBackground(Color.BLACK);
b2.setForeground(Color.WHITE);
        
b1.addActionListener(this);
b2.addActionListener(this);
        
c2.addItemListener(this);
        
setVisible(true);
setSize(400,550);
setLocation(600,200);
        
getContentPane().setBackground(Color.BLACK);
}
    
public void actionPerformed(ActionEvent ae){
if(ae.getSource()==b1){String p = t1.getText();
//String g = c1.getSelectedItem();
String t = t2.getText();
String d = t3.getText();
String f = t4.getText();//String u = t6.getText();
//String an = t7.getText();
String qry = "update bank_details set name='"+p+"',gender='"+t+"',address='"+d+"',profession='"+f+"'   where id="+c2.getSelectedItem();
       
try{
conn c1 = new conn();
c1.s.executeUpdate(qry);
JOptionPane.showMessageDialog(null,"payment Updated");
}
catch(Exception ee){
ee.printStackTrace();
}
}
        
if(ae.getSource()==b2){
try{
conn c1 = new conn();
c1.s.executeUpdate("delete from bank_details where pid="+c2.getSelectedItem());
JOptionPane.showMessageDialog(null,"payment deleted");
this.setVisible(false);
}catch(Exception ee){
ee.printStackTrace();
}
}
}
    
public void itemStateChanged(ItemEvent ie){
try{
conn c1 = new conn();
ResultSet rs = c1.s.executeQuery("select * from payment where pid="+c2.getSelectedItem());
            
if(rs.next()){
t1.setText(rs.getString("payment_id"));
t2.setText(rs.getString("tax"));
t3.setText(rs.getString("due_date"));
t4.setText(rs.getString("fine"));
//t6.setText(rs.getString("utr"));
//t7.setText(rs.getString("account_number"));
}
}

catch(Exception ee){
ee.printStackTrace();
}
}
    
public static void main(String[] args){
Update_payment update_payment = new Update_payment();
}    
}
