import java.sql.*;

public class conn {    
public Connection conn;
public Statement s;
public PreparedStatement pstmt;
public conn(){
try{
Class.forName("oracle.jdbc.OracleDriver");
conn=DriverManager.getConnection("jdbc:oracle:thin:@218.248.0.7:1521:rdbms","it20737041","vasavi");;
System.out.println("Connected");
s = conn.createStatement();
}
catch(Exception e) {
e.printStackTrace();
}
}    
}

