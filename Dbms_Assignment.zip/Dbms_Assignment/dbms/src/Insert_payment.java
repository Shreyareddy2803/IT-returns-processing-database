import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Insert_payment extends JFrame implements ActionListener{
JLabel l1,l2,l3,l4;
JTextField t1,t2,t3,t4;
JButton b1,b2;
Choice c1;
Insert_payment(){
super("Payment");
//setSize(600,650);
//setLocation(600,200);
setLayout(null);
getContentPane().setBackground(Color.WHITE);

//JPanel p1= new JPanel();
//p1.setBackground(Color.BLACK);    
//p1.setLayout(new GridLayout(8,2,10,40));

l1 = new JLabel("Payment_id");
l1.setForeground(Color.WHITE);
l1.setBackground(Color.BLACK);
        
t1 = new JTextField(15);
t1.setBackground(Color.BLACK);
t1.setForeground(Color.WHITE);
        
//p1.add(l1);
//p1.add(t1);
l1.setBounds(40,80,100,20);
t1.setBounds(160,80,200,20);
add(l1);
add(t1);


/*c1 = new Choice();
c1.add("Male");
c1.add("Female");
c1.add("Others");
c1.setBackground(Color.BLACK);
c1.setForeground(Color.WHITE);

l2 = new JLabel("Gender");
l2.setForeground(Color.WHITE);
l2.setBackground(Color.BLACK);

l2.setBounds(40,120,100,20);
c1.setBounds(162,120,200,20);
add(l2);
add(c1);
        
//p1.add(l2);
//p1.add(c1);*/
l2 = new JLabel("tax");
l2.setForeground(Color.WHITE);
l2.setBackground(Color.BLACK);
        
t2 = new JTextField(15);
t2.setBackground(Color.BLACK);
t2.setForeground(Color.WHITE);

l2.setBounds(40,160,100,20);
t2.setBounds(160,160,200,20);
add(l2);
add(t2);
//p1.add(l3);
//1.add(t3);
l3 = new JLabel("due_date");
l3.setForeground(Color.WHITE);
l3.setBackground(Color.BLACK);
        
t3 = new JTextField(15);
t3.setBackground(Color.BLACK);
t3.setForeground(Color.WHITE);

l3.setBounds(40,200,100,20);
t3.setBounds(160,200,200,20);
add(l3);
add(t3);
        
//p1.add(l4);
//p1.add(t4); 
l4 = new JLabel("fine");
l4.setForeground(Color.WHITE);
l4.setBackground(Color.BLACK);
        
t4 = new JTextField(15);
t4.setBackground(Color.BLACK);
t4.setForeground(Color.WHITE);

l4.setBounds(40,240,100,20);
t4.setBounds(160,240,200,20);
add(l4);
add(t4);
//p1.add(l5);
//p1.add(t5);

/*l6 = new JLabel("utr");
l6.setForeground(Color.WHITE);
l6.setBackground(Color.BLACK);

t6 = new JTextField(15);
t6.setBackground(Color.BLACK);
t6.setForeground(Color.WHITE);
  
l6.setBounds(40,280,100,20);
t6.setBounds(160,280,200,20);
add(l6);
add(t6);
//p1.add(l6);
//p1.add(t6);
l7 = new JLabel("account_number");
l7.setForeground(Color.WHITE);
l7.setBackground(Color.BLACK);      

t7= new JTextField(15);
t7.setBackground(Color.BLACK);
t7.setForeground(Color.WHITE);

l7.setBounds(40,320,100,20);
t7.setBounds(160,320,200,20);
add(l7);
add(t7);
        
//p1.add(l7);
//p1.add(t7);*/
b1 =new JButton("Submit");
b2 = new JButton("Cancel");
//p1.add(b1);
//p1.add(b2);
b1.setBounds(40,400,150,30);
b2.setBounds(200,400,150,30);
add(b1);
add(b2);
       
//setLayout(new BorderLayout());
//add(new JLabel(new ImageIcon
//(ClassLoader.getSystemResource("icons/new_employee.png"))),"West");
//add(p1,"Center");
     
b1.addActionListener(this);
b1.setBackground(Color.BLACK);
b1.setForeground(Color.WHITE);
b2.addActionListener(this);
b2.setBackground(Color.BLACK);
b2.setForeground(Color.WHITE);
setVisible(true);
setSize(400,550);
setLocation(600,200);

getContentPane().setBackground(Color.BLACK);
}
public void actionPerformed(ActionEvent ae){
       
String p = t1.getText();
//String g = c1.getSelectedItem();
String t = t2.getText();
String d = t3.getText();
String f = t4.getText();
//String u = t6.getText();
//String an = t7.getText();
String qry = "insert into bank_details values(null,'"+p+"','"+t+"','"+d+"','"+f+"')";
try{
conn c1 = new conn();
c1.s.executeUpdate(qry);
JOptionPane.showMessageDialog(null,"PAYMENTS Created");
this.setVisible(false);  
}
catch(Exception ee){
ee.printStackTrace();
}
}
    
public static void main(String s[]){
new Insert_payment().setVisible(true);
}
}
